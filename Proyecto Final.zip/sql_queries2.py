DDL_QUERY =  '''
CREATE TABLE actividad
(idactividad_sk INT NOT NULL,
ActividadEconomica VARCHAR (200) NOT NULL,
SubActividadEconomica VARCHAR (50) NOT NULL,
CONSTRAINT sk_idactividad PRIMARY KEY (idactividad_sk));

CREATE TABLE producto
(producto_sk INT  NOT NULL,
FamiliaProducto VARCHAR (100) NOT NULL,
CONSTRAINT sk_producto PRIMARY KEY (producto_sk));

CREATE TABLE departamento
(oficina_sk INT  NOT NULL,
oficina VARCHAR (100) NOT NULL,
region VARCHAR (100) NOT NULL,
CONSTRAINT sk_oficina PRIMARY KEY (oficina_sk));

CREATE TABLE cliente
(IdCliente_sk INT  NOT NULL,
edad INT NOT NULL,
RangoEdad VARCHAR(50),
Genero VARCHAR (50),
EstadoCivil VARCHAR (50),
CONSTRAINT sk_IdCliente PRIMARY KEY (IdCliente_sk));

CREATE TABLE fac_table
(idactividad_sk INT NOT NULL,
producto_sk INT NOT NULL,
oficina_sk INT NOT NULL,
IdCliente_sk INT NOT NULL,
NumeroCredito BIGINT NOT NULL,
Cosecha INT NOT NULL,
FechaDesembolso DATE NOT NULL,
MontoCredito NUMERIC (20,2) NOT NULL,
CuotaCredito NUMERIC (20,2) NOT NULL,
Plazo INT NOT NULL,
TipoVivienda VARCHAR (100) NOT NULL,
CONSTRAINT fk_idactividad FOREIGN KEY (idactividad_sk) REFERENCES actividad (idactividad_sk),
CONSTRAINT fk_producto FOREIGN KEY (producto_sk) REFERENCES producto (producto_sk),
CONSTRAINT fk_oficina FOREIGN KEY (oficina_sk) REFERENCES  departamento (oficina_sk),
CONSTRAINT fk_IdCliente FOREIGN KEY (IdCliente_sk) REFERENCES cliente (IdCliente_sk));'''