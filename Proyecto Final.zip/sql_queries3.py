DDL_QUERY3 =  '''
CREATE TABLE facturacion
(idactividad_sk INT NOT NULL,
facturacion VARCHAR (200) NOT NULL,
CONSTRAINT sk_idfacturacion PRIMARY KEY (idactividad_sk));'''